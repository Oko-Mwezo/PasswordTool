import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import hashlib
import itertools
import string
from datetime import datetime
import os
import threading

class PasswordAnalyzer:
    def __init__(self, common_passwords_file='common_passwords.txt'):
        self.common_passwords = self.load_common_passwords(common_passwords_file)
    
    def load_common_passwords(self, filename):
        common_passwords = set()
        try:
            with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    common_passwords.add(line.strip().lower())
        except FileNotFoundError:
            print(f"Warning: {filename} not found. Common password check disabled.")
        return common_passwords
    
    def analyze_password(self, password):
        results = {
            'password': password,
            'length': len(password),
            'has_upper': any(c.isupper() for c in password),
            'has_lower': any(c.islower() for c in password),
            'has_digit': any(c.isdigit() for c in password),
            'has_special': any(not c.isalnum() for c in password),
            'is_common': password.lower() in self.common_passwords,
            'score': 0,
            'strength': 'Very Weak'
        }
        
        # Calculate score
        results['score'] += min(results['length'] * 4, 40)
        if results['has_upper']: results['score'] += 10
        if results['has_lower']: results['score'] += 10
        if results['has_digit']: results['score'] += 10
        if results['has_special']: results['score'] += 15
        if results['is_common']: results['score'] = max(0, results['score'] - 50)
        
        # Determine strength
        if results['score'] >= 80:
            results['strength'] = 'Very Strong'
        elif results['score'] >= 60:
            results['strength'] = 'Strong'
        elif results['score'] >= 40:
            results['strength'] = 'Moderate'
        elif results['score'] >= 20:
            results['strength'] = 'Weak'
        
        return results

class WordlistGenerator:
    def generate_wordlist(self, user_info, output_file='custom_wordlist.txt', max_length=8):
        words = set()
        base_words = []
        
        for key, value in user_info.items():
            if value:
                if isinstance(value, str):
                    base_words.extend(value.split())
                    base_words.append(value)
                elif isinstance(value, (int, float)):
                    base_words.append(str(value))
        
        base_words = list(set(base_words))
        
        for word in base_words:
            if word:
                words.add(word)
                words.add(word.lower())
                words.add(word.upper())
                words.add(word.capitalize())
                
                substituted = word.lower()
                substituted = substituted.replace('a', '@')
                substituted = substituted.replace('s', '$')
                substituted = substituted.replace('i', '!')
                substituted = substituted.replace('o', '0')
                substituted = substituted.replace('e', '3')
                words.add(substituted)
        
        for i in range(1, min(3, len(base_words)) + 1):
            for combo in itertools.combinations(base_words, i):
                combined = ''.join(combo)
                if 3 <= len(combined) <= max_length:
                    words.add(combined)
                    words.add(combined.lower())
                    words.add(combined.upper())
        
        numbers = ['123', '1234', '12345', '123456', '111', '222', '333', '444', '555', 
                  '666', '777', '888', '999', '000', '007', '69', '420']
        special_combos = ['!', '@', '#', '$', '%', '&', '*', '!!', '!!!', '!@#', '#$%']
        
        temp_words = list(words)
        for word in temp_words:
            for number in numbers:
                if len(word + number) <= max_length:
                    words.add(word + number)
                    words.add(number + word)
            for special in special_combos:
                if len(word + special) <= max_length:
                    words.add(word + special)
                    words.add(special + word)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            for word in sorted(words, key=len):
                if 3 <= len(word) <= max_length:
                    f.write(word + '\n')
        
        return len(words)

class PasswordCracker:
    def __init__(self):
        self.attempts = 0
        self.stop_cracking = False
    
    def crack_md5(self, target_hash, wordlist_file, salt=None, progress_callback=None):
        start_time = datetime.now()
        self.attempts = 0
        self.stop_cracking = False
        
        try:
            with open(wordlist_file, 'r', encoding='utf-8', errors='ignore') as f:
                total_lines = sum(1 for _ in f)
                f.seek(0)
                
                for i, password in enumerate(f):
                    if self.stop_cracking:
                        return {'found': False, 'stopped': True}
                    
                    password = password.strip()
                    self.attempts += 1
                    
                    if salt:
                        test_string = salt + password
                    else:
                        test_string = password
                    
                    hashed = hashlib.md5(test_string.encode()).hexdigest()
                    
                    if progress_callback and i % 100 == 0:
                        progress_callback(i / total_lines * 100)
                    
                    if hashed == target_hash:
                        end_time = datetime.now()
                        time_taken = (end_time - start_time).total_seconds()
                        return {
                            'found': True,
                            'password': password,
                            'attempts': self.attempts,
                            'time_taken': time_taken,
                            'salt_used': salt is not None
                        }
        
        except FileNotFoundError:
            return {'found': False, 'error': 'Wordlist file not found'}
        
        end_time = datetime.now()
        time_taken = (end_time - start_time).total_seconds()
        return {
            'found': False,
            'attempts': self.attempts,
            'time_taken': time_taken,
            'salt_used': salt is not None
        }

class PasswordToolGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Password Security Toolkit")
        self.root.geometry("800x600")
        self.root.configure(bg='#2b2b2b')
        
        self.analyzer = PasswordAnalyzer()
        self.generator = WordlistGenerator()
        self.cracker = PasswordCracker()
        
        self.setup_ui()
    
    def setup_ui(self):
        # Create notebook (tabs)
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Create frames for each tab
        analyze_frame = ttk.Frame(notebook, padding=10)
        generate_frame = ttk.Frame(notebook, padding=10)
        crack_frame = ttk.Frame(notebook, padding=10)
        
        notebook.add(analyze_frame, text='Password Analysis')
        notebook.add(generate_frame, text='Wordlist Generator')
        notebook.add(crack_frame, text='Password Cracker')
        
        self.setup_analyze_tab(analyze_frame)
        self.setup_generate_tab(generate_frame)
        self.setup_crack_tab(crack_frame)
    
    def setup_analyze_tab(self, frame):
        ttk.Label(frame, text="Password Analyzer", font=('Arial', 14, 'bold')).pack(pady=10)
        
        # Password input
        input_frame = ttk.Frame(frame)
        input_frame.pack(fill='x', pady=5)
        
        ttk.Label(input_frame, text="Enter Password:").pack(side='left')
        self.password_var = tk.StringVar()
        password_entry = ttk.Entry(input_frame, textvariable=self.password_var, show='*', width=30)
        password_entry.pack(side='left', padx=5)
        
        show_btn = ttk.Button(input_frame, text="Show", command=self.toggle_password_visibility)
        show_btn.pack(side='left', padx=5)
        
        analyze_btn = ttk.Button(input_frame, text="Analyze", command=self.analyze_password)
        analyze_btn.pack(side='left', padx=5)
        
        # Results area
        self.results_text = scrolledtext.ScrolledText(frame, height=15, width=70)
        self.results_text.pack(pady=10, fill='both', expand=True)
        self.results_text.config(state='disabled')
    
    def setup_generate_tab(self, frame):
        ttk.Label(frame, text="Wordlist Generator", font=('Arial', 14, 'bold')).pack(pady=10)
        
        # Input fields
        fields = [
            ('Full Name', 'name_var'),
            ('Birth Year', 'birthyear_var'),
            ('Pet Name', 'pet_var'),
            ('Company', 'company_var'),
            ('Other Keywords', 'keywords_var')
        ]
        
        for label, var_name in fields:
            row = ttk.Frame(frame)
            row.pack(fill='x', pady=2)
            ttk.Label(row, text=f"{label}:", width=15).pack(side='left')
            setattr(self, var_name, tk.StringVar())
            ttk.Entry(row, textvariable=getattr(self, var_name), width=30).pack(side='left', padx=5)
        
        # Options
        options_frame = ttk.Frame(frame)
        options_frame.pack(fill='x', pady=10)
        
        ttk.Label(options_frame, text="Max Length:").pack(side='left')
        self.max_length_var = tk.StringVar(value="8")
        ttk.Spinbox(options_frame, from_=4, to=20, textvariable=self.max_length_var, width=5).pack(side='left', padx=5)
        
        ttk.Label(options_frame, text="Output File:").pack(side='left', padx=(20,5))
        self.output_file_var = tk.StringVar(value="custom_wordlist.txt")
        ttk.Entry(options_frame, textvariable=self.output_file_var, width=20).pack(side='left')
        ttk.Button(options_frame, text="Browse", command=self.browse_output_file).pack(side='left', padx=5)
        
        # Generate button
        ttk.Button(frame, text="Generate Wordlist", command=self.generate_wordlist).pack(pady=10)
        
        # Status
        self.generate_status = ttk.Label(frame, text="")
        self.generate_status.pack(pady=5)
    
    def setup_crack_tab(self, frame):
        ttk.Label(frame, text="MD5 Password Cracker", font=('Arial', 14, 'bold')).pack(pady=10)
        
        # Hash input
        hash_frame = ttk.Frame(frame)
        hash_frame.pack(fill='x', pady=5)
        ttk.Label(hash_frame, text="MD5 Hash:").pack(side='left')
        self.hash_var = tk.StringVar()
        ttk.Entry(hash_frame, textvariable=self.hash_var, width=40).pack(side='left', padx=5)
        
        # Wordlist selection
        wordlist_frame = ttk.Frame(frame)
        wordlist_frame.pack(fill='x', pady=5)
        ttk.Label(wordlist_frame, text="Wordlist File:").pack(side='left')
        self.wordlist_var = tk.StringVar()
        ttk.Entry(wordlist_frame, textvariable=self.wordlist_var, width=30).pack(side='left', padx=5)
        ttk.Button(wordlist_frame, text="Browse", command=self.browse_wordlist).pack(side='left')
        
        # Salt
        salt_frame = ttk.Frame(frame)
        salt_frame.pack(fill='x', pady=5)
        ttk.Label(salt_frame, text="Salt (optional):").pack(side='left')
        self.salt_var = tk.StringVar()
        ttk.Entry(salt_frame, textvariable=self.salt_var, width=20).pack(side='left', padx=5)
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        progress_bar = ttk.Progressbar(frame, variable=self.progress_var, maximum=100)
        progress_bar.pack(fill='x', pady=10)
        
        # Buttons
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Start Cracking", command=self.start_cracking).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Stop", command=self.stop_cracking).pack(side='left', padx=5)
        
        # Results
        self.crack_results = scrolledtext.ScrolledText(frame, height=10, width=70)
        self.crack_results.pack(pady=10, fill='both', expand=True)
        self.crack_results.config(state='disabled')
    
    def toggle_password_visibility(self):
        current = self.password_var.get()
        if hasattr(self, '_password_visible') and self._password_visible:
            self.password_var.set('*' * len(current))
            self._password_visible = False
        else:
            self.password_var.set(current)
            self._password_visible = True
    
    def analyze_password(self):
        password = self.password_var.get()
        if not password:
            messagebox.showerror("Error", "Please enter a password to analyze")
            return
        
        result = self.analyzer.analyze_password(password)
        
        self.results_text.config(state='normal')
        self.results_text.delete(1.0, tk.END)
        
        output = f"""Password Analysis Results:
──────────────────────────
Password: {result['password']}
Length: {result['length']} characters
Contains uppercase: {result['has_upper']}
Contains lowercase: {result['has_lower']}
Contains digits: {result['has_digit']}
Contains special chars: {result['has_special']}
Is common password: {result['is_common']}

Strength score: {result['score']}/100
Strength: {result['strength']}

Recommendations:
────────────────"""
        
        recommendations = []
        if result['length'] < 8:
            recommendations.append("• Use at least 8 characters")
        if not result['has_upper']:
            recommendations.append("• Add uppercase letters")
        if not result['has_lower']:
            recommendations.append("• Add lowercase letters")
        if not result['has_digit']:
            recommendations.append("• Add numbers")
        if not result['has_special']:
            recommendations.append("• Add special characters")
        if result['is_common']:
            recommendations.append("• Avoid common passwords")
        
        if not recommendations:
            recommendations.append("• Good job! Your password is strong")
        
        output += "\n" + "\n".join(recommendations)
        
        self.results_text.insert(tk.END, output)
        self.results_text.config(state='disabled')
    
    def browse_output_file(self):
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.output_file_var.set(filename)
    
    def browse_wordlist(self):
        filename = filedialog.askopenfilename(
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.wordlist_var.set(filename)
    
    def generate_wordlist(self):
        user_info = {
            'name': self.name_var.get(),
            'birthyear': self.birthyear_var.get(),
            'pet': self.pet_var.get(),
            'company': self.company_var.get(),
            'keywords': self.keywords_var.get()
        }
        
        # Combine all non-empty values
        all_info = []
        for value in user_info.values():
            if value:
                if isinstance(value, str):
                    all_info.extend(value.split())
        
        if not all_info:
            messagebox.showerror("Error", "Please provide at least one piece of information")
            return
        
        try:
            max_length = int(self.max_length_var.get())
            output_file = self.output_file_var.get()
            
            count = self.generator.generate_wordlist(
                {'info': ' '.join(all_info)},
                output_file,
                max_length
            )
            
            self.generate_status.config(text=f"Generated {count} passwords in {output_file}")
            messagebox.showinfo("Success", f"Generated {count} passwords in {output_file}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to generate wordlist: {str(e)}")
    
    def start_cracking(self):
        target_hash = self.hash_var.get().strip()
        wordlist_file = self.wordlist_var.get()
        salt = self.salt_var.get().strip() or None
        
        if not target_hash or len(target_hash) != 32:
            messagebox.showerror("Error", "Please enter a valid 32-character MD5 hash")
            return
        
        if not wordlist_file:
            messagebox.showerror("Error", "Please select a wordlist file")
            return
        
        # Run in separate thread to avoid freezing GUI
        def crack_thread():
            self.progress_var.set(0)
            self.update_crack_results("Starting cracking process...\n")
            
            result = self.cracker.crack_md5(
                target_hash, wordlist_file, salt,
                lambda p: self.progress_var.set(p)
            )
            
            if result.get('found'):
                output = f"""Password found!
────────────────
Password: {result['password']}
Attempts: {result['attempts']:,}
Time taken: {result['time_taken']:.2f} seconds"""
                if result['salt_used']:
                    output += f"\nSalt used: {salt}"
            elif result.get('stopped'):
                output = "Cracking stopped by user"
            else:
                output = f"""Password not found
────────────────
Attempts: {result['attempts']:,}
Time taken: {result['time_taken']:.2f} seconds"""
                if result.get('error'):
                    output += f"\nError: {result['error']}"
            
            self.update_crack_results(output + "\n")
        
        threading.Thread(target=crack_thread, daemon=True).start()
    
    def stop_cracking(self):
        self.cracker.stop_cracking = True
    
    def update_crack_results(self, text):
        self.root.after(0, lambda: self._update_crack_results(text))
    
    def _update_crack_results(self, text):
        self.crack_results.config(state='normal')
        self.crack_results.insert(tk.END, text + "\n")
        self.crack_results.see(tk.END)
        self.crack_results.config(state='disabled')

def main():
    root = tk.Tk()
    app = PasswordToolGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()